# QuoteMachineTemplate
Repositorio de template do projeto "quote machine" que será dado em sala de aula
